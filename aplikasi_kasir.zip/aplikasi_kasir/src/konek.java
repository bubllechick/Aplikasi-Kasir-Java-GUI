 
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.xml.transform.Result;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Zakaria
 */
public class konek {
    public Connection con;
    public Statement stat;
    public ResultSet rs; 
    
public Connection getConnection(){
    try {
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kasir", "root", "");
    }
    catch (Exception e){
        JOptionPane.showMessageDialog(null, "GAGAL KONEKSI");
    }
        return con;
    
    
    
    
    
}
}
